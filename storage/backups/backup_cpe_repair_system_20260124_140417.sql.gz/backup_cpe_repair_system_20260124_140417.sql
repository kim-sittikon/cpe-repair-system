-- MySQL dump 10.13  Distrib 8.4.7, for Linux (x86_64)
--
-- Host: localhost    Database: cpe_repair_system
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `account_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','student','staff','teacher') COLLATE utf8mb4_unicode_ci NOT NULL,
  `otp_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_expires` timestamp NULL DEFAULT NULL,
  `credit` int NOT NULL DEFAULT '0',
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `job_repair` tinyint(1) NOT NULL DEFAULT '0',
  `job_admin` tinyint(1) NOT NULL DEFAULT '0',
  `job_complaint` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `invited_by` bigint unsigned DEFAULT NULL,
  `invitation_sent_at` timestamp NULL DEFAULT NULL,
  `invitation_expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `accounts_email_unique` (`email`),
  KEY `accounts_invited_by_foreign` (`invited_by`),
  CONSTRAINT `accounts_invited_by_foreign` FOREIGN KEY (`invited_by`) REFERENCES `accounts` (`account_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,'Super','Admin','admin@rmutt.ac.th','$2y$12$99iNh3WT2H5ygi09WGKDsOPPabw4hA.jZ86xRxXW2PndQGRGp/RiW','admin',NULL,NULL,0,1,'active',1,1,1,NULL,'2026-01-07 16:18:30','2026-01-07 16:18:30',NULL,NULL,NULL),(2,'Staff','Repairman','staff@rmutt.ac.th','$2y$12$ycxtofwhmi3WDjkQwIPaH.NVVfkSoTJC0K7yd8R5mcuMnI.8SqMbS','staff',NULL,NULL,0,1,'active',1,0,0,NULL,'2026-01-07 16:18:30','2026-01-07 16:18:30',NULL,NULL,NULL),(3,'Teacher','User','teacher@rmutt.ac.th','$2y$12$BlPY5LNK1L3c/qS0XWbV8.bU02vbAQN5xHhqwmLaISnTL6DP..pSW','teacher',NULL,NULL,0,1,'active',0,0,1,NULL,'2026-01-07 16:18:30','2026-01-07 16:18:30',NULL,NULL,NULL),(4,'Student','User','student@mail.rmutt.ac.th','$2y$12$hrufh/h73AbowDWxw6hUNu/HNhalxzE4Xucw9pL/Za8GKhekAh7J2','student',NULL,NULL,0,1,'active',0,0,0,NULL,'2026-01-07 16:18:30','2026-01-07 16:18:30',NULL,NULL,NULL),(5,'Kim','Mm','kaiwa2203@gmail.com','$2y$12$c3zYVXi87PgpcdcvxK..fuBRAAsgbMN85nPBBUAOmPVza0KPNkSvq','staff',NULL,NULL,0,1,'active',1,0,1,NULL,'2026-01-09 12:40:08','2026-01-09 12:40:08',1,'2026-01-09 12:38:37','2026-01-12 12:38:37');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcement`
--

DROP TABLE IF EXISTS `announcement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcement` (
  `announcement_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_urgent` tinyint(1) NOT NULL DEFAULT '0',
  `file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` bigint unsigned NOT NULL,
  `building_id` bigint unsigned DEFAULT NULL,
  `room_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`announcement_id`),
  KEY `announcement_account_id_foreign` (`account_id`),
  KEY `announcement_building_id_foreign` (`building_id`),
  KEY `announcement_room_id_foreign` (`room_id`),
  CONSTRAINT `announcement_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`account_id`) ON DELETE CASCADE,
  CONSTRAINT `announcement_building_id_foreign` FOREIGN KEY (`building_id`) REFERENCES `building` (`building_id`) ON DELETE SET NULL,
  CONSTRAINT `announcement_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `room` (`room_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement`
--

LOCK TABLES `announcement` WRITE;
/*!40000 ALTER TABLE `announcement` DISABLE KEYS */;
INSERT INTO `announcement` VALUES (1,'บำรุงรักษาเครื่อง Server ประจำไตรมาส','จะมีการปิดปรับปรุงระบบ Server เพื่อทำการบำรุงรักษา ในวันที่ 14 Sep 2025 เวลา 22.00 - 02.00 น.',1,NULL,1,NULL,NULL,'2026-01-06 16:18:31','2026-01-08 03:43:05','2026-01-08 03:43:05'),(2,'งดการเรียนการสอน ห้อง CPE_Lab1','เนื่องจากมีการสอบกลางภาค จึงของดใช้ห้อง Lab 1 ในช่วงเช้าวันพรุ่งนี้',1,NULL,1,1,NULL,'2026-01-07 11:18:31','2026-01-08 03:43:04','2026-01-08 03:43:04'),(3,'ปิดปรับปรุงระบบเครือข่าย อาคาร CPE ชั้น 2','รายละเอียดเพิ่มเติมเกี่ยวกับ ปิดปรับปรุงระบบเครือข่าย อาคาร CPE ชั้น 2 สามารถติดต่อสอบถามได้ที่สำนักงาน',0,NULL,2,NULL,NULL,'2026-01-05 16:18:31','2026-01-08 03:42:49','2026-01-08 03:42:49'),(4,'แจ้งกำหนดการส่งคืนอุปกรณ์ยืมเรียน','รายละเอียดเพิ่มเติมเกี่ยวกับ แจ้งกำหนดการส่งคืนอุปกรณ์ยืมเรียน สามารถติดต่อสอบถามได้ที่สำนักงาน',0,NULL,2,NULL,NULL,'2026-01-04 16:18:31','2026-01-08 03:43:02','2026-01-08 03:43:02'),(5,'รับสมัครนักศึกษาช่วยงานฝ่ายอาคาร','รายละเอียดเพิ่มเติมเกี่ยวกับ รับสมัครนักศึกษาช่วยงานฝ่ายอาคาร สามารถติดต่อสอบถามได้ที่สำนักงาน',0,NULL,2,NULL,NULL,'2026-01-03 16:18:31','2026-01-08 03:42:53','2026-01-08 03:42:53'),(6,'กิจกรรม Big Cleaning Day ประจำปี','รายละเอียดเพิ่มเติมเกี่ยวกับ กิจกรรม Big Cleaning Day ประจำปี สามารถติดต่อสอบถามได้ที่สำนักงาน',0,NULL,2,NULL,NULL,'2026-01-02 16:18:31','2026-01-08 03:42:59','2026-01-08 03:42:59'),(7,'ก','ก',0,'uploads/announcements/bfa45b43-df83-4116-bab6-49d66eaa71ac.webp',1,NULL,NULL,'2026-01-07 18:05:04','2026-01-08 03:42:56','2026-01-08 03:42:56'),(8,'หหฟด','ฟหดฟด',1,'uploads/announcements/7875936e-efd2-462c-9ba2-d0f4c50f6b44.webp',1,NULL,NULL,'2026-01-07 18:05:34','2026-01-08 03:50:28','2026-01-08 03:50:28');
/*!40000 ALTER TABLE `announcement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `building`
--

DROP TABLE IF EXISTS `building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `building` (
  `building_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `building_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`building_id`),
  KEY `building_account_id_foreign` (`account_id`),
  CONSTRAINT `building_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`account_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `building`
--

LOCK TABLES `building` WRITE;
/*!40000 ALTER TABLE `building` DISABLE KEYS */;
INSERT INTO `building` VALUES (1,'Computer Engineering Building (ตึกคอม)',1,'2026-01-07 16:18:30','2026-01-07 16:18:30'),(2,'Engineering Build 1',1,'2026-01-07 16:18:30','2026-01-07 16:18:30'),(3,'Engineering Build 2',1,'2026-01-07 16:18:31','2026-01-07 16:18:31');
/*!40000 ALTER TABLE `building` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('cpe-repair-system-cache-admin@mail.rmutt.ac.th|172.18.0.1','i:1;',1767962129),('cpe-repair-system-cache-admin@mail.rmutt.ac.th|172.18.0.1:timer','i:1767962129;',1767962129),('cpe-repair-system-cache-b7ad7f2b04bd98f199a2b8c016e37e66c831b866','i:1;',1767962082),('cpe-repair-system-cache-b7ad7f2b04bd98f199a2b8c016e37e66c831b866:timer','i:1767962082;',1767962082),('cpe-repair-system-cache-illuminate:queue:restart','i:1767961565;',2083321565),('cpe-repair-system-cache-keywords_global_complaint','a:0:{}',2083198456),('cpe-repair-system-cache-keywords_personal_complaint','O:39:\"Illuminate\\Database\\Eloquent\\Collection\":2:{s:8:\"\0*\0items\";a:0:{}s:28:\"\0*\0escapeWhenCastingToString\";b:0;}',2083198456),('cpe-repair-system-cache-otp_1166304620394@mail.rmutt.ac.th','s:6:\"274582\";',1767962322),('cpe-repair-system-cache-otp_preprjct@mail.rmutt.ac.th','s:6:\"875013\";',1767845131);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complaints_keywords`
--

DROP TABLE IF EXISTS `complaints_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `complaints_keywords` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `keyword_text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `complaints_keywords_account_id_foreign` (`account_id`),
  CONSTRAINT `complaints_keywords_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`account_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complaints_keywords`
--

LOCK TABLES `complaints_keywords` WRITE;
/*!40000 ALTER TABLE `complaints_keywords` DISABLE KEYS */;
/*!40000 ALTER TABLE `complaints_keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_complaint`
--

DROP TABLE IF EXISTS `file_complaint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_complaint` (
  `file_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `complaint_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`file_id`),
  KEY `file_complaint_complaint_id_foreign` (`complaint_id`),
  CONSTRAINT `file_complaint_complaint_id_foreign` FOREIGN KEY (`complaint_id`) REFERENCES `requests_complaint` (`complaint_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_complaint`
--

LOCK TABLES `file_complaint` WRITE;
/*!40000 ALTER TABLE `file_complaint` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_complaint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_job`
--

DROP TABLE IF EXISTS `file_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_job` (
  `file_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jobstep_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`file_id`),
  KEY `file_job_jobstep_id_foreign` (`jobstep_id`),
  CONSTRAINT `file_job_jobstep_id_foreign` FOREIGN KEY (`jobstep_id`) REFERENCES `jobstep` (`jobstep_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_job`
--

LOCK TABLES `file_job` WRITE;
/*!40000 ALTER TABLE `file_job` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_repair`
--

DROP TABLE IF EXISTS `file_repair`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_repair` (
  `file_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `repair_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`file_id`),
  KEY `file_repair_repair_id_foreign` (`repair_id`),
  CONSTRAINT `file_repair_repair_id_foreign` FOREIGN KEY (`repair_id`) REFERENCES `requests_repair` (`repair_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_repair`
--

LOCK TABLES `file_repair` WRITE;
/*!40000 ALTER TABLE `file_repair` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_repair` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job`
--

DROP TABLE IF EXISTS `job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job` (
  `job_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`job_id`),
  KEY `job_created_by_foreign` (`created_by`),
  CONSTRAINT `job_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `accounts` (`account_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job`
--

LOCK TABLES `job` WRITE;
/*!40000 ALTER TABLE `job` DISABLE KEYS */;
INSERT INTO `job` VALUES (1,'Fix Air Conditioner Task',1,'2026-01-07 16:18:31','2026-01-07 16:18:31');
/*!40000 ALTER TABLE `job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobactor`
--

DROP TABLE IF EXISTS `jobactor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobactor` (
  `jobstep_id` bigint unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`jobstep_id`),
  CONSTRAINT `jobactor_jobstep_id_foreign` FOREIGN KEY (`jobstep_id`) REFERENCES `jobstep` (`jobstep_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobactor`
--

LOCK TABLES `jobactor` WRITE;
/*!40000 ALTER TABLE `jobactor` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobactor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobapprover`
--

DROP TABLE IF EXISTS `jobapprover`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobapprover` (
  `jobstep_id` bigint unsigned NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`jobstep_id`),
  CONSTRAINT `jobapprover_jobstep_id_foreign` FOREIGN KEY (`jobstep_id`) REFERENCES `jobstep` (`jobstep_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobapprover`
--

LOCK TABLES `jobapprover` WRITE;
/*!40000 ALTER TABLE `jobapprover` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobapprover` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobstep`
--

DROP TABLE IF EXISTS `jobstep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobstep` (
  `jobstep_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `step_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `step_number` int NOT NULL,
  `action` enum('act','app') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `step_details` text COLLATE utf8mb4_unicode_ci,
  `completeDT` datetime DEFAULT NULL,
  `assigned_account_id` bigint unsigned DEFAULT NULL,
  `job_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`jobstep_id`),
  KEY `jobstep_assigned_account_id_foreign` (`assigned_account_id`),
  KEY `jobstep_job_id_foreign` (`job_id`),
  CONSTRAINT `jobstep_assigned_account_id_foreign` FOREIGN KEY (`assigned_account_id`) REFERENCES `accounts` (`account_id`) ON DELETE SET NULL,
  CONSTRAINT `jobstep_job_id_foreign` FOREIGN KEY (`job_id`) REFERENCES `job` (`job_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobstep`
--

LOCK TABLES `jobstep` WRITE;
/*!40000 ALTER TABLE `jobstep` DISABLE KEYS */;
INSERT INTO `jobstep` VALUES (1,'Check Issue',1,'act','done',NULL,'2026-01-07 16:18:31',2,1,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(2,'Fixing',2,'act','in_progress',NULL,NULL,2,1,'2026-01-07 16:18:31','2026-01-07 16:18:31');
/*!40000 ALTER TABLE `jobstep` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `keyword_matches`
--

DROP TABLE IF EXISTS `keyword_matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `keyword_matches` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `request_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_id` bigint unsigned NOT NULL,
  `keyword` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `owner_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keyword_matches`
--

LOCK TABLES `keyword_matches` WRITE;
/*!40000 ALTER TABLE `keyword_matches` DISABLE KEYS */;
/*!40000 ALTER TABLE `keyword_matches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `keywords`
--

DROP TABLE IF EXISTS `keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `keywords` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('repair','complaint') COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope` enum('global','personal') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'personal',
  `keyword` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creator_id` bigint unsigned DEFAULT NULL,
  `editor_id` bigint unsigned DEFAULT NULL,
  `deleter_id` bigint unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keywords_type_keyword_unique` (`type`,`keyword`),
  KEY `keywords_creator_id_foreign` (`creator_id`),
  KEY `keywords_editor_id_foreign` (`editor_id`),
  KEY `keywords_deleter_id_foreign` (`deleter_id`),
  CONSTRAINT `keywords_creator_id_foreign` FOREIGN KEY (`creator_id`) REFERENCES `accounts` (`account_id`) ON DELETE SET NULL,
  CONSTRAINT `keywords_deleter_id_foreign` FOREIGN KEY (`deleter_id`) REFERENCES `accounts` (`account_id`) ON DELETE SET NULL,
  CONSTRAINT `keywords_editor_id_foreign` FOREIGN KEY (`editor_id`) REFERENCES `accounts` (`account_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keywords`
--

LOCK TABLES `keywords` WRITE;
/*!40000 ALTER TABLE `keywords` DISABLE KEYS */;
/*!40000 ALTER TABLE `keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2025_12_11_103300_create_accounts_table',1),(5,'2025_12_11_103301_create_buildings_table',1),(6,'2025_12_11_103302_create_rooms_table',1),(7,'2025_12_11_103338_create_requests_repair_table',1),(8,'2025_12_11_103339_create_requests_complaint_table',1),(9,'2025_12_11_103404_create_jobs_table',1),(10,'2025_12_11_103405_create_jobsteps_table',1),(11,'2025_12_11_103405_create_request_job_map_table',1),(12,'2025_12_11_103406_create_jobactors_table',1),(13,'2025_12_11_103406_create_jobapprovers_table',1),(14,'2025_12_11_103407_create_announcements_table',1),(15,'2025_12_11_103407_create_file_repair_table',1),(16,'2025_12_11_103408_create_file_complaint_table',1),(17,'2025_12_11_103408_create_file_job_table',1),(18,'2025_12_11_103409_create_complaints_keywords_table',1),(19,'2025_12_11_103409_create_repair_keywords_table',1),(20,'2025_12_14_072351_create_keywords_table',1),(21,'2025_12_14_082223_add_audit_fields_to_keywords_table',1),(22,'2025_12_17_114634_add_invitation_fields_to_accounts_table',1),(23,'2025_12_22_072952_add_role_and_status_to_users_table',1),(24,'2026_01_04_153436_add_scope_to_keywords_table',1),(25,'2026_01_04_173617_create_keyword_matches_table',1),(26,'2026_01_07_112042_add_deleted_at_to_announcement_table',1),(27,'2026_01_08_031703_create_user_invitations_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repair_keywords`
--

DROP TABLE IF EXISTS `repair_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repair_keywords` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `keyword_text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `repair_keywords_account_id_foreign` (`account_id`),
  CONSTRAINT `repair_keywords_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`account_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repair_keywords`
--

LOCK TABLES `repair_keywords` WRITE;
/*!40000 ALTER TABLE `repair_keywords` DISABLE KEYS */;
INSERT INTO `repair_keywords` VALUES (1,'แอร์ (Air)',2,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(2,'ไฟ (Light)',2,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(3,'คอมพิวเตอร์ (Computer)',2,'2026-01-07 16:18:31','2026-01-07 16:18:31');
/*!40000 ALTER TABLE `repair_keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `request_job_map`
--

DROP TABLE IF EXISTS `request_job_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `request_job_map` (
  `map_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `job_id` bigint unsigned NOT NULL,
  `repair_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`map_id`),
  KEY `request_job_map_job_id_foreign` (`job_id`),
  KEY `request_job_map_repair_id_foreign` (`repair_id`),
  CONSTRAINT `request_job_map_job_id_foreign` FOREIGN KEY (`job_id`) REFERENCES `job` (`job_id`) ON DELETE CASCADE,
  CONSTRAINT `request_job_map_repair_id_foreign` FOREIGN KEY (`repair_id`) REFERENCES `requests_repair` (`repair_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `request_job_map`
--

LOCK TABLES `request_job_map` WRITE;
/*!40000 ALTER TABLE `request_job_map` DISABLE KEYS */;
INSERT INTO `request_job_map` VALUES (1,1,1,'2026-01-07 16:18:31','2026-01-07 16:18:31');
/*!40000 ALTER TABLE `request_job_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requests_complaint`
--

DROP TABLE IF EXISTS `requests_complaint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `requests_complaint` (
  `complaint_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `priority` tinyint NOT NULL DEFAULT '1',
  `account_id` bigint unsigned NOT NULL,
  `building_id` bigint unsigned DEFAULT NULL,
  `room_id` bigint unsigned DEFAULT NULL,
  `credited` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`complaint_id`),
  KEY `requests_complaint_account_id_foreign` (`account_id`),
  KEY `requests_complaint_building_id_foreign` (`building_id`),
  KEY `requests_complaint_room_id_foreign` (`room_id`),
  CONSTRAINT `requests_complaint_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`account_id`) ON DELETE CASCADE,
  CONSTRAINT `requests_complaint_building_id_foreign` FOREIGN KEY (`building_id`) REFERENCES `building` (`building_id`) ON DELETE SET NULL,
  CONSTRAINT `requests_complaint_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `room` (`room_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requests_complaint`
--

LOCK TABLES `requests_complaint` WRITE;
/*!40000 ALTER TABLE `requests_complaint` DISABLE KEYS */;
INSERT INTO `requests_complaint` VALUES (1,'Complaint #1','Noise issue.','pending',1,3,NULL,NULL,0,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(2,'Complaint #2','Noise issue.','pending',1,3,NULL,NULL,0,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(3,'Complaint #3','Noise issue.','pending',1,3,NULL,NULL,0,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(4,'Complaint #4','Noise issue.','pending',1,3,NULL,NULL,0,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(5,'Complaint #5','Noise issue.','pending',1,3,NULL,NULL,0,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(6,'ห','ห','pending',1,1,NULL,NULL,0,'2026-01-07 18:03:33','2026-01-07 18:03:33');
/*!40000 ALTER TABLE `requests_complaint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requests_repair`
--

DROP TABLE IF EXISTS `requests_repair`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `requests_repair` (
  `repair_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `priority` tinyint NOT NULL DEFAULT '1',
  `account_id` bigint unsigned NOT NULL,
  `building_id` bigint unsigned NOT NULL,
  `room_id` bigint unsigned NOT NULL,
  `credited` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`repair_id`),
  KEY `requests_repair_account_id_foreign` (`account_id`),
  KEY `requests_repair_building_id_foreign` (`building_id`),
  KEY `requests_repair_room_id_foreign` (`room_id`),
  CONSTRAINT `requests_repair_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`account_id`) ON DELETE CASCADE,
  CONSTRAINT `requests_repair_building_id_foreign` FOREIGN KEY (`building_id`) REFERENCES `building` (`building_id`) ON DELETE CASCADE,
  CONSTRAINT `requests_repair_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `room` (`room_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requests_repair`
--

LOCK TABLES `requests_repair` WRITE;
/*!40000 ALTER TABLE `requests_repair` DISABLE KEYS */;
INSERT INTO `requests_repair` VALUES (1,'Repair Request #1','Something is broken.','pending',2,4,1,1,0,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(2,'Repair Request #2','Something is broken.','pending',1,4,1,1,0,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(3,'Repair Request #3','Something is broken.','pending',3,4,1,1,0,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(4,'Repair Request #4','Something is broken.','pending',3,4,1,1,0,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(5,'Repair Request #5','Something is broken.','pending',1,4,1,1,0,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(6,'Repair Request #6','Something is broken.','in_progress',3,4,1,1,0,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(7,'Repair Request #7','Something is broken.','in_progress',3,4,1,1,0,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(8,'Repair Request #8','Something is broken.','in_progress',2,4,1,1,0,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(9,'Repair Request #9','Something is broken.','in_progress',2,4,1,1,0,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(10,'Repair Request #10','Something is broken.','in_progress',1,4,1,1,0,'2026-01-07 16:18:31','2026-01-07 16:18:31');
/*!40000 ALTER TABLE `requests_repair` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room` (
  `room_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `room_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `building_id` bigint unsigned NOT NULL,
  `account_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`room_id`),
  KEY `room_building_id_foreign` (`building_id`),
  KEY `room_account_id_foreign` (`account_id`),
  CONSTRAINT `room_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`account_id`) ON DELETE CASCADE,
  CONSTRAINT `room_building_id_foreign` FOREIGN KEY (`building_id`) REFERENCES `building` (`building_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (1,'CPE_Lab1',1,1,'2026-01-07 16:18:30','2026-01-07 16:18:30'),(2,'CPE_Lab2',1,1,'2026-01-07 16:18:30','2026-01-07 16:18:30'),(3,'401',1,1,'2026-01-07 16:18:30','2026-01-07 16:18:30'),(4,'402',1,1,'2026-01-07 16:18:30','2026-01-07 16:18:30'),(5,'403',1,1,'2026-01-07 16:18:30','2026-01-07 16:18:30'),(6,'En1_101',2,1,'2026-01-07 16:18:30','2026-01-07 16:18:30'),(7,'En1_102',2,1,'2026-01-07 16:18:30','2026-01-07 16:18:30'),(8,'En1_201',2,1,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(9,'En1_202',2,1,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(10,'En1_Meeting',2,1,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(11,'En2_LabA',3,1,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(12,'En2_LabB',3,1,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(13,'En2_Office',3,1,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(14,'En2_Hall',3,1,'2026-01-07 16:18:31','2026-01-07 16:18:31'),(15,'En2_Storage',3,1,'2026-01-07 16:18:31','2026-01-07 16:18:31');
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('0lVRlVD9SpeI2iYjWsaJHNXg4ZGSAKiiCVIe2AQq',NULL,'172.18.0.1','Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ1N4d1pkQW5ldVF1ZHR1Q2VLbGFvTTJjakRGdWJmd2pzS1U5Vnh4TiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjA6Imh0dHA6Ly9jcGVyZXBhaXIuYXBwIjtzOjU6InJvdXRlIjtOO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1769233239),('1CJWnTA222FI0JqsMPia0MpWl8wCNXCwuLrgULbB',1,'172.18.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Safari/605.1.15','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMHhvVFRNRTZ0QTNjOGRobTZqRXJzOFdnbk1aSzFtWHYxTTFlSmxxaSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NjE6Imh0dHA6Ly9tYXJjZWxsYS1kcnlzLXNseXZpYS5uZ3Jvay1mcmVlLmRldi9hZG1pbi91c2Vycy9pbnZpdGUiO3M6NToicm91dGUiO3M6MTg6ImFkbWluLnVzZXJzLmludml0ZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==',1767964553),('BsaQVjrtahKicKWQNPu6F0GyRvL4FExRUMxHX55J',NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoid3d4RTQ2c01zaFZoUWJWclR1aWNBYk5aMG9LanB5Q2FFRXE1NGtaNSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly9jcGVyZXBhaXIuYXBwL2xvZ2luIjtzOjU6InJvdXRlIjtzOjU6ImxvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1769233237),('cmKjCnIotbGbvdL4QroDE68X4sedEZQJbeZAV0h5',NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSzZQTVMxdW95cGhtOXV1d05uVE1MZlFKaWNCR2FsQkhuUDRKSFNiVSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHA6Ly9sb2NhbGhvc3QvbG9naW4iO3M6NToicm91dGUiO3M6NToibG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1767957602),('DeeBbIh7RJap04BgyC8y3L8WFA3kXk1fnI9S2zjb',NULL,'172.18.0.1','','YToyOntzOjY6Il90b2tlbiI7czo0MDoiRmRmRXNmNmN6UWNXZ2FxelhrZkNzbTBHQXhxUmJ1TEpXcWhaQ3NQTiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1767960499),('iXrLv3TVy5x56Hu0D4NZKupdFaPb2RLdazdll5No',NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNkNJaUhRSFhyVnBZSVNSQk1mY0xyMWdpTTBhbmp0TEVsVmd1WEl6NSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly9jcGVyZXBhaXIuYXBwL2xvZ2luIjtzOjU6InJvdXRlIjtzOjU6ImxvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1769236066),('jsxntaPzoaB6HcLJRrukqY8kGEox7J5WPd4pjF3E',NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWlNDV0xXZTd2S0tFRWJ5aFFpTzNEWTNFVTE5dXVxMm5icnZpTlJHSiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDg6Imh0dHA6Ly9tYXJjZWxsYS1kcnlzLXNseXZpYS5uZ3Jvay1mcmVlLmRldi9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1767961288),('KxSYPZwN6xtTQJv0uvM6jHEtmha0CiI57G7YKAQk',NULL,'172.18.0.1','','YToyOntzOjY6Il90b2tlbiI7czo0MDoiQ1pZems0VkFzTE1zQnZibWt6UGdiQjhteXJYUThDN0tCQ1BMUklzTiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1767960499),('l6xEEgObBPg9ltG1bgkPvr3i7rKE7QB1S95Xjq6a',1,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMlMyQmp2TE9uUWJHVm5rUGpmN0l4SHNacEIzaGRLZWdNRlpaSUVReSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly9sb2NhbGhvc3QvZGFzaGJvYXJkIjtzOjU6InJvdXRlIjtzOjk6ImRhc2hib2FyZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==',1767959916),('ni2Iv9wclUuBVUynDHtZ2h3yzwSXgGtdRB7axtmD',5,'172.18.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiZmVpeGJ5bHZPbDM0dW9VMlgxNHo1cHdBOU0wQ2JOZWVXNHc3MzhsaSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTM4OiJodHRwOi8vbWFyY2VsbGEtZHJ5cy1zbHl2aWEubmdyb2stZnJlZS5kZXYvaW52aXRlL1FkazE4OWE1M2ZDM2FObDF3MnNSYVk0YjFqV09GZUd3VDUwR1IxWXZIcEdKcnAzR1VYdVdsNnVnd2xxSj9lbWFpbD1rYWl3YTIyMDMlNDBnbWFpbC5jb20iO3M6NToicm91dGUiO3M6MTE6Imludml0ZS5zaG93Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6NTt9',1767962408),('Oa8dnZFL8dzu5f5vPkhGGZ730Cgs8lPi6kBA62Tx',NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoicjZXb0RlVXdMNmx2VUVpRW5yTkh2QkptTUo5b2FwMnNvdEhkcGo5VCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDg6Imh0dHA6Ly9tYXJjZWxsYS1kcnlzLXNseXZpYS5uZ3Jvay1mcmVlLmRldi9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1767960961),('oggWn9x2tACN0Hc1z7FRhjO89Skg65jeWqtyUfX6',NULL,'172.18.0.1','','YToyOntzOjY6Il90b2tlbiI7czo0MDoieFdOZGNvNm9zd2dtcWVZaG5IWHRlcFpaRTNkd3E5SmwwMnN0YmNONiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1767961822),('oPFgnUnLBRsO2WUbSclx3vUdxK85DGrVzzW4p5bK',NULL,'172.18.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQVFvdlNITnowYXo2WjdBM0ZKdWxzcEFuVU9Dc09sNGlMTVFHNVRvNSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly9jcGVyZXBhaXIuYXBwL2xvZ2luIjtzOjU6InJvdXRlIjtzOjU6ImxvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1769236050),('pCGLZaFKmS9xWBMeflkLPlzCpNV2I1DVIIZqJL72',NULL,'172.18.0.1','','YToyOntzOjY6Il90b2tlbiI7czo0MDoiVUQxRWZocGVCemRrNERMQkdRa0ZUZEFhUGpkazEwem1VTnUxNDd5RSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1767961822),('qkPOF4kchQ93DmnnSGmKDe9LVTbDHJICtTVmmbE0',NULL,'172.18.0.1','curl/8.5.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSU84NlBNTHJNcWw2ejVHWjRDYkhXUmlsM3h3MDBNellQUmhJUm9nQSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjM6Imh0dHA6Ly9sb2NhbGhvc3QvaGVhbHRoIjtzOjU6InJvdXRlIjtzOjI3OiJnZW5lcmF0ZWQ6OnRUTlhHaDV1MGtUemhkWlkiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1769238224),('QrhI38uVNs487Pbgc5eFp86GHiko2wK5JPq5XDar',NULL,'172.18.0.1','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoidTVIZklvY3A3WnZVYnE5Y2dRelBURG95dmhUSDQzeWVSSHBKcGJkcyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly9jcGVyZXBhaXIuYXBwL2xvZ2luIjtzOjU6InJvdXRlIjtzOjU6ImxvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1769233295),('rE8FvOdfzxyxxole1HofnWny5pvddVuv1f3x28aD',NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiaDJqZDlRdTRGVmZrUDQ4V3hLNjBSc3NsZDhPekNaa1BJa3RJYWg1WiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly9ob3N0LmRvY2tlci5pbnRlcm5hbCI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1768730198),('vHBcs0qcYgmwuTk0lnfkbE2vuBclezob1xoOE9nP',NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZDFiOTVVZVY2eVRpamRXc1hydXlKZmZYc0Z4ZTZoeFdyRkdlSGpiMCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTY6Imh0dHA6Ly9sb2NhbGhvc3QiO3M6NToicm91dGUiO047fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1767957827),('XnccGtPJpSEsGQnTvXV8WZMoKspFlQIDSY96IoW0',NULL,'172.18.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiZTlmQWgwb1BTMXBMd1N0MXNKdHhZMUl6endZNzQ4ODJVNkhRT1hjbiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo0MjoiaHR0cHM6Ly9jcGVyZXBhaXIuYXBwL2Fubm91bmNlbWVudHMvY3JlYXRlIjt9czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly9jcGVyZXBhaXIuYXBwL2xvZ2luIjtzOjU6InJvdXRlIjtzOjU6ImxvZ2luIjt9fQ==',1769236075),('YII6wfc4kJajINkjPn1V6N25q75uIbBdMyLi6rAt',NULL,'172.18.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiU3kxdTZVbFo5RGt3VDh4TFNIVnRWdzlKNFlEemFDU0NMeGd6V0RJaiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly9jcGVyZXBhaXIuYXBwL2xvZ2luIjtzOjU6InJvdXRlIjtzOjU6ImxvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1769236119);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_invitations`
--

DROP TABLE IF EXISTS `user_invitations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_invitations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','student','staff','teacher') COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` json NOT NULL,
  `invited_by` bigint unsigned NOT NULL,
  `expires_at` timestamp NOT NULL,
  `accepted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_invitations_token_unique` (`token`),
  KEY `user_invitations_invited_by_foreign` (`invited_by`),
  KEY `user_invitations_email_index` (`email`),
  KEY `user_invitations_expires_at_index` (`expires_at`),
  CONSTRAINT `user_invitations_invited_by_foreign` FOREIGN KEY (`invited_by`) REFERENCES `accounts` (`account_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_invitations`
--

LOCK TABLES `user_invitations` WRITE;
/*!40000 ALTER TABLE `user_invitations` DISABLE KEYS */;
INSERT INTO `user_invitations` VALUES (2,'kaiwa2203@gmail.com','$2y$12$7oWPMBrmvf9dzph1ID4YKuPQKCsyu5b7r1qbB5tjlagkyJEseg.pG','staff','{\"job_admin\": false, \"job_repair\": true, \"job_complaint\": true}',1,'2026-01-12 12:38:37','2026-01-09 12:40:08','2026-01-09 12:38:37','2026-01-09 12:40:08');
/*!40000 ALTER TABLE `user_invitations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'student',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-24  7:04:18
